import java.io.*;
import java.net.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.Timer;

public class Server extends JFrame implements ActionListener {

    DatagramSocket RTPsocket;
    DatagramPacket senddp;

    InetAddress ClientIPAddr;
    int RTP_dest_port = 0;
    int RTSP_dest_port = 0;

    JLabel label;

    int imagenb = 0;
    VideoStream video;
    static int MJPEG_TYPE = 26;
    static int FRAME_PERIOD = 30;
    static int VIDEO_LENGTH = 500;

    Timer timer;
    byte[] buf;
    int sendDelay;

    final static int INIT = 0;
    final static int READY = 1;
    final static int PLAYING = 2;

    final static int SETUP = 3;
    final static int PLAY = 4;
    final static int PAUSE = 5;
    final static int TEARDOWN = 6;

    static int state;
    Socket RTSPsocket;
    static BufferedReader RTSPBufferedReader;
    static BufferedWriter RTSPBufferedWriter;
    static String VideoFileName;
    static String RTSPid = UUID.randomUUID().toString();
    int RTSPSeqNb = 0;

    final static String CRLF = "\r\n";

    public Server() {

        super("RTSP Server");

        sendDelay = FRAME_PERIOD;
        timer = new Timer(sendDelay, this);
        timer.setInitialDelay(0);
        timer.setCoalesce(true);

        buf = new byte[20000];

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                timer.stop();
                System.exit(0);
            }
        });

        label = new JLabel("Send frame number ", JLabel.CENTER);
        label.setFont(new Font("Calibri", Font.BOLD, 30));
        getContentPane().add(label, BorderLayout.CENTER);
    }

    public static void main(String argv[]) throws Exception {
        Server server = new Server();

        server.pack();
        server.setVisible(true);
        server.setSize(new Dimension(400, 220));

        int RTSPport = Integer.parseInt(argv[0]);
        server.RTSP_dest_port = RTSPport;

        ServerSocket listenSocket = new ServerSocket(RTSPport);
        server.RTSPsocket = listenSocket.accept();
        listenSocket.close();

        server.ClientIPAddr = server.RTSPsocket.getInetAddress();

        state = INIT;

        RTSPBufferedReader = new BufferedReader(new InputStreamReader(server.RTSPsocket.getInputStream()));
        RTSPBufferedWriter = new BufferedWriter(new OutputStreamWriter(server.RTSPsocket.getOutputStream()));

        int request_type;
        boolean done = false;
        while (!done) {
            request_type = server.parseRequest();

            if (request_type == SETUP) {
                done = true;

                state = READY;
                System.out.println("New RTSP state: READY");

                server.sendResponse();

                server.video = new VideoStream(VideoFileName);

                server.RTPsocket = new DatagramSocket();
            }
        }

        while (true) {
            request_type = server.parseRequest();
            if ((request_type == PLAY) && (state == READY)) {
                server.sendResponse();
                server.timer.start();

                state = PLAYING;
                System.out.println("New RTSP state: PLAYING");
            } else if ((request_type == PAUSE) && (state == PLAYING)) {
                server.sendResponse();
                server.timer.stop();
                state = READY;
                System.out.println("New RTSP state: READY");
            } else if (request_type == TEARDOWN) {
                server.sendResponse();
                server.timer.stop();
                server.RTSPsocket.close();
                server.RTPsocket.close();

                System.exit(0);
            }
        }
    }

    public void actionPerformed(ActionEvent e) {

        if (imagenb < VIDEO_LENGTH) {
            imagenb++;

            try {
                int image_length = video.getnextframe(buf);
                RTPpacket rtp_packet = new RTPpacket(MJPEG_TYPE, imagenb, imagenb * FRAME_PERIOD, buf, image_length);
                int packet_length = rtp_packet.getlength();
                byte[] packet_bits = new byte[packet_length];
                rtp_packet.getpacket(packet_bits);
                senddp = new DatagramPacket(packet_bits, packet_length, ClientIPAddr, RTP_dest_port);
                RTPsocket.send(senddp);
                System.out
                        .println("Send frame number " + imagenb + ", Frame size: " + image_length + " (" + buf.length
                                + ")");
                rtp_packet.printheader();
                label.setText("Send frame number " + imagenb);
            } catch (Exception ex) {
                System.out.println("Exception caught: " + ex);
                System.exit(0);
            }
        } else {
            timer.stop();
        }
    }

    private int parseRequest() {
        int request_type = -1;
        try {
            String RequestLine = RTSPBufferedReader.readLine();
            System.out.println("RTSP Server - Received from Client:");
            System.out.println(RequestLine);

            StringTokenizer tokens = new StringTokenizer(RequestLine);
            String request_type_string = tokens.nextToken();

            if ((new String(request_type_string)).compareTo("SETUP") == 0)
                request_type = SETUP;
            else if ((new String(request_type_string)).compareTo("PLAY") == 0)
                request_type = PLAY;
            else if ((new String(request_type_string)).compareTo("PAUSE") == 0)
                request_type = PAUSE;
            else if ((new String(request_type_string)).compareTo("TEARDOWN") == 0)
                request_type = TEARDOWN;

            if (request_type == SETUP) {
                VideoFileName = tokens.nextToken();
            }

            String SeqNumLine = RTSPBufferedReader.readLine();
            System.out.println(SeqNumLine);
            tokens = new StringTokenizer(SeqNumLine);
            tokens.nextToken();
            RTSPSeqNb = Integer.parseInt(tokens.nextToken());

            String LastLine = RTSPBufferedReader.readLine();
            System.out.println(LastLine);

            tokens = new StringTokenizer(LastLine);
            if (request_type == SETUP) {
                for (int i = 0; i < 3; i++)
                    tokens.nextToken();
                RTP_dest_port = Integer.parseInt(tokens.nextToken());
            } else {
                tokens.nextToken();
                RTSPid = tokens.nextToken();
            }
        } catch (Exception ex) {
            System.out.println("Exception caught: " + ex);
            System.exit(0);
        }

        return (request_type);
    }

    private void sendResponse() {
        try {
            RTSPBufferedWriter.write("RTSP/1.0 200 OK" + CRLF);
            RTSPBufferedWriter.write("CSeq: " + RTSPSeqNb + CRLF);
            RTSPBufferedWriter.write("Session: " + RTSPid + CRLF);
            RTSPBufferedWriter.flush();
            System.out.println("RTSP Server - Sent response to Client.");
        } catch (Exception ex) {
            System.out.println("Exception caught: " + ex);
            System.exit(0);
        }
    }
}
