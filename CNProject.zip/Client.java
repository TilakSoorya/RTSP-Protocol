import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.Timer;

public class Client {

    JFrame f = new JFrame("Client");
    JButton setupButton = new JButton("Setup");
    JButton playButton = new JButton("Play");
    JButton pauseButton = new JButton("Pause");
    JButton tearButton = new JButton("Close");
    JPanel mainPanel = new JPanel();
    JPanel buttonPanel = new JPanel();
    JLabel statLabel1 = new JLabel();
    JLabel statLabel2 = new JLabel();
    JLabel statLabel3 = new JLabel();
    JLabel iconLabel = new JLabel();
    ImageIcon icon;

    DatagramPacket rcvdp;
    DatagramSocket RTPsocket;
    static int RTP_RCV_PORT = 25000;
    Timer timer;
    byte[] buf;

    final static int INIT = 0;
    final static int READY = 1;
    final static int PLAYING = 2;
    static int state;
    Socket RTSPsocket;
    InetAddress ServerIPAddr;

    static BufferedReader RTSPBufferedReader;
    static BufferedWriter RTSPBufferedWriter;
    static String VideoFileName;
    int RTSPSeqNb = 0;
    String RTSPid;
    final static String CRLF = "\r\n";

    static int MJPEG_TYPE = 26;

    double statDataRate;
    int statTotalBytes;
    double statStartTime;
    double statTotalPlayTime;
    float statFractionLost;
    int statCumLost;
    int statExpRtpNb;
    int statHighSeqNb;

    FrameSynchronizer fsynch;

    public Client() {

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        buttonPanel.setLayout(new GridLayout(1, 0));
        buttonPanel.add(setupButton);
        buttonPanel.add(playButton);
        buttonPanel.add(pauseButton);
        buttonPanel.add(tearButton);

        setupButton.addActionListener(new setupButtonListener());
        playButton.addActionListener(new playButtonListener());
        pauseButton.addActionListener(new pauseButtonListener());
        tearButton.addActionListener(new tearButtonListener());

        setupButton.setBackground(Color.BLACK);
        playButton.setBackground(Color.BLACK);
        pauseButton.setBackground(Color.BLACK);
        tearButton.setBackground(Color.BLACK);

        statLabel1.setText("Total Bytes Received: 0");
        statLabel2.setText("Packets Lost: 0");
        statLabel3.setText("Data Rate (bytes/sec): 0");

        setupButton.setForeground(Color.WHITE);
        playButton.setForeground(Color.WHITE);
        pauseButton.setForeground(Color.WHITE);
        tearButton.setForeground(Color.WHITE);

        iconLabel.setIcon(null);
        mainPanel.setLayout(null);
        mainPanel.add(iconLabel);
        mainPanel.add(buttonPanel);
        mainPanel.add(statLabel1);
        mainPanel.add(statLabel2);
        mainPanel.add(statLabel3);
        iconLabel.setBounds(0, 0, 380, 280);
        buttonPanel.setBounds(0, 280, 380, 50);
        statLabel1.setBounds(110, 345, 380, 20);
        statLabel2.setBounds(110, 365, 380, 20);
        statLabel3.setBounds(110, 385, 380, 20);

        f.getContentPane().add(mainPanel, BorderLayout.CENTER);
        f.setSize(new Dimension(390, 450));
        f.setVisible(true);
        f.setLocation(900, 0);
        timer = new Timer(20, new timerListener());
        timer.setInitialDelay(0);
        timer.setCoalesce(true);

        buf = new byte[15000];
        fsynch = new FrameSynchronizer(100);
    }

    public static void main(String argv[]) throws Exception {

        Client theClient = new Client();
        int RTSP_server_port = Integer.parseInt(argv[1]);
        String ServerHost = argv[0];
        theClient.ServerIPAddr = InetAddress.getByName(ServerHost);
        VideoFileName = argv[2];
        theClient.RTSPsocket = new Socket(theClient.ServerIPAddr, RTSP_server_port);

        RTSPBufferedReader = new BufferedReader(new InputStreamReader(theClient.RTSPsocket.getInputStream()));
        RTSPBufferedWriter = new BufferedWriter(new OutputStreamWriter(theClient.RTSPsocket.getOutputStream()));

        state = INIT;
    }

    class setupButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            System.out.println("Setup Button pressed !");
            if (state == INIT) {
                try {
                    RTPsocket = new DatagramSocket(RTP_RCV_PORT);
                    RTPsocket.setSoTimeout(5);
                } catch (SocketException se) {
                    System.out.println("Socket exception: " + se);
                    System.exit(0);
                }
                RTSPSeqNb = 1;
                sendRequest("SETUP");
                if (parseServerResponse() != 200)
                    System.out.println("Invalid Server Response");
                else {
                    state = READY;
                    System.out.println("New RTSP state: READY");
                }
            }
        }
    }

    class playButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            System.out.println("Play Button pressed!");
            statStartTime = System.currentTimeMillis();

            if (state == READY) {
                RTSPSeqNb++;
                sendRequest("PLAY");
                if (parseServerResponse() != 200) {
                    System.out.println("Invalid Server Response");
                } else {
                    state = PLAYING;
                    System.out.println("New RTSP state: PLAYING");
                    timer.start();
                }
            }

        }
    }

    class pauseButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            System.out.println("Pause Button pressed!");
            if (state == PLAYING) {
                RTSPSeqNb++;
                sendRequest("PAUSE");

                if (parseServerResponse() != 200)
                    System.out.println("Invalid Server Response");
                else {
                    state = READY;
                    System.out.println("New RTSP state: READY");
                    timer.stop();
                }
            }

        }
    }

    class tearButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            System.out.println("Teardown Button pressed !");
            RTSPSeqNb++;
            sendRequest("TEARDOWN");

            if (parseServerResponse() != 200)
                System.out.println("Invalid Server Response");
            else {
                state = INIT;
                System.out.println("New RTSP state: INIT");
                timer.stop();
                System.exit(0);
            }
        }
    }

    class timerListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            rcvdp = new DatagramPacket(buf, buf.length);
            try {
                RTPsocket.receive(rcvdp);
                double curTime = System.currentTimeMillis();
                statTotalPlayTime += curTime - statStartTime;
                statStartTime = curTime;

                RTPpacket rtp_packet = new RTPpacket(rcvdp.getData(), rcvdp.getLength());
                int seqNb = rtp_packet.getsequencenumber();

                System.out.println("Got RTP packet with SeqNum # " + seqNb
                        + " TimeStamp " + rtp_packet.gettimestamp() + " ms, of type "
                        + rtp_packet.getpayloadtype());

                rtp_packet.printheader();

                int payload_length = rtp_packet.getpayload_length();
                byte[] payload = new byte[payload_length];
                rtp_packet.getpayload(payload);
                statExpRtpNb++;

                if (seqNb > statHighSeqNb) {
                    statHighSeqNb = seqNb;
                }
                if (statExpRtpNb != seqNb) {
                    statCumLost++;
                }
                statDataRate = statTotalPlayTime == 0 ? 0 : (statTotalBytes / (statTotalPlayTime / 1000.0));
                statFractionLost = (float) statCumLost / statHighSeqNb;
                statTotalBytes += payload_length;
                updateStatsLabel();

                Toolkit toolkit = Toolkit.getDefaultToolkit();
                fsynch.addFrame(toolkit.createImage(payload, 0, payload_length), seqNb);

                icon = new ImageIcon(fsynch.nextFrame());
                iconLabel.setIcon(icon);
            } catch (InterruptedIOException iioe) {
                System.out.println("Nothing to read");
            } catch (IOException ioe) {
                System.out.println("Exception caught: " + ioe);
            }
        }
    }

    class FrameSynchronizer {

        private ArrayDeque<Image> queue;
        private int bufSize;
        private int curSeqNb;
        private Image lastImage;

        public FrameSynchronizer(int bsize) {
            curSeqNb = 1;
            bufSize = bsize;
            queue = new ArrayDeque<Image>(bufSize);
        }

        public void addFrame(Image image, int seqNum) {
            if (seqNum < curSeqNb) {
                queue.add(lastImage);
            } else if (seqNum > curSeqNb) {
                for (int i = curSeqNb; i < seqNum; i++) {
                    queue.add(lastImage);
                }
                queue.add(image);
            } else {
                queue.add(image);
            }
        }

        public Image nextFrame() {
            curSeqNb++;
            lastImage = queue.peekLast();
            return queue.remove();
        }
    }

    private int parseServerResponse() {
        int reply_code = 0;

        try {
            String StatusLine = RTSPBufferedReader.readLine();
            System.out.println("RTSP Client - Received from Server:");
            System.out.println(StatusLine);

            StringTokenizer tokens = new StringTokenizer(StatusLine);
            tokens.nextToken();
            reply_code = Integer.parseInt(tokens.nextToken());

            if (reply_code == 200) {
                String SeqNumLine = RTSPBufferedReader.readLine();
                System.out.println(SeqNumLine);

                String SessionLine = RTSPBufferedReader.readLine();
                System.out.println(SessionLine);

                tokens = new StringTokenizer(SessionLine);
                String temp = tokens.nextToken();

                if (state == INIT && temp.compareTo("Session:") == 0) {
                    RTSPid = tokens.nextToken();
                }
            }
        } catch (Exception ex) {
            System.out.println("Exception caught: " + ex);
            System.exit(0);
        }

        return (reply_code);
    }

    private void updateStatsLabel() {
        DecimalFormat formatter = new DecimalFormat("###,###.##");
        statLabel1.setText("Total Bytes Received: " + statTotalBytes);
        statLabel2.setText("Packet Lost Rate: " + formatter.format(statFractionLost));
        statLabel3.setText("Data Rate: " + formatter.format(statDataRate) + " bytes/s");
    }

    private void sendRequest(String request_type) {
        try {

            RTSPBufferedWriter.write(request_type + " " + VideoFileName + " RTSP/1.0" + CRLF);
            RTSPBufferedWriter.write("CSeq: " + RTSPSeqNb + CRLF);
            if (request_type == "SETUP") {
                RTSPBufferedWriter.write("Transport: RTP/UDP; client_port= " + RTP_RCV_PORT + CRLF);
            } else {
                RTSPBufferedWriter.write("Session: " + RTSPid + CRLF);
            }
            RTSPBufferedWriter.flush();
        } catch (Exception ex) {
            System.out.println("Exception caught: " + ex);
            System.exit(0);
        }
    }
}
